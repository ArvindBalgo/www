
CREATE TABLE `orders_main` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `total_livraison_ht` float NOT NULL,
  `total_livraison_ttc` float NOT NULL,
  `total_prix_ht` float NOT NULL,
  `total_prix_ttc` float NOT NULL,
  `tax` float NOT NULL,
  `total_prix_net` float NOT NULL,
  `status` text NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `orders_main` (`id`, `id_user`, `total_livraison_ht`, `total_livraison_ttc`, `total_prix_ht`, `total_prix_ttc`, `tax`, `total_prix_net`, `status`, `date_created`, `date_modified`, `created_by`, `modified_by`, `comments`) VALUES
(71, 182, 7.75, 9.3, 191, 229.2, 38.2, 0, 'NEW', '2017-07-28 01:46:39', '2017-07-28 01:46:39', 182, 182, ''),
(72, 188, 6.85, 8.22, 44.5, 53.4, 8.9, 0, 'FACONNAGE', '2017-07-28 05:41:36', '2017-07-28 14:12:45', 188, 181, ''),
(73, 188, 8, 9.6, 144, 172.8, 28.8, 0, 'NEW', '2017-07-31 08:12:21', '2017-07-31 08:12:21', 188, 188, '');
