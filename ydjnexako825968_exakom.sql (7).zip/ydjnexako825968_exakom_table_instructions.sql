
CREATE TABLE `instructions` (
  `id` int(11) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `instructions` (`id`, `instruction`) VALUES
(1, 'RÃ©alisez votre maquette gratuitement.'),
(2, 'Choisissez votre activitÃ© et votre produit, entrez dans votre espace crÃ©ation.'),
(3, 'SchÃ©matisez votre maquette, elle sera traitÃ©e par nos graphistes en 48h.'),
(4, 'TÃ©lÃ©chargez vos photos, logos, maquettes, nous rÃ©alisons vos projets.'),
(5, 'Banques dâ€™images, maquettes, logos 100% Free.'),
(6, 'Notre unique objectif : votre satisfaction!'),
(7, 'Exakom en toute confiance.');
