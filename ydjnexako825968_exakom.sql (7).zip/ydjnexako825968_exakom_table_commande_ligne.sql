
CREATE TABLE `commande_ligne` (
  `id` int(11) NOT NULL,
  `src` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `commande_ligne` (`id`, `src`, `title`) VALUES
(1, 'images/flat_images/product_1477721272.png', 'SAC VERGE'),
(2, 'images/flat_images/product_1477721272.png', 'SAC VERGE'),
(3, 'images/gallery/simple.png', 'Recto'),
(4, 'images/gallery/recto.jpg', 'Recto Verso');
