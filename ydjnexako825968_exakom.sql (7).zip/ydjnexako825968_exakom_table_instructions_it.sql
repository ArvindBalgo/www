
CREATE TABLE `instructions_it` (
  `id` int(11) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `instructions_it` (`id`, `instruction`) VALUES
(1, 'Realizzate il vostro impianto grafico gratis.'),
(2, 'Scegliete la vostra attivitÃ  e il vostro prodotto, entrate nel vostro spazio creativo.'),
(3, 'Schematizzate il vostro progetto sarÃ  sviluppato dai nostri grafici in 48 ore.'),
(4, 'Caricate le vostre foto , il vostro logo e il progetto e lo realizzeremo per voi.'),
(5, 'Foto, logo, grafico 100% gratis.'),
(6, 'Il nostro unico obbiettivo Ã¨ la vostra soddisfazione.'),
(7, 'Tutto con la massima riservatezza');
