
CREATE TABLE `customers_auth` (
  `uid` int(11) NOT NULL,
  `company_name` text COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pays` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'FR',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` int(11) NOT NULL DEFAULT '0',
  `surname` text COLLATE utf8_unicode_ci NOT NULL,
  `admintype` int(11) NOT NULL DEFAULT '0',
  `postalcode` int(11) NOT NULL,
  `nosiret` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `customers_auth` (`uid`, `company_name`, `name`, `email`, `phone`, `password`, `address`, `city`, `pays`, `created`, `admin`, `surname`, `admintype`, `postalcode`, `nosiret`) VALUES
(179, '', 'Arvind', 'balgo_arvind@hotmail.com', '59125334', '$2a$10$e80dbf222f1288ddf527duE7AvmS5PnfSjPsxS6Fi5A7X9673n6T2', 'Gbois', '', 'FR', '2016-07-13 16:46:50', 1, '', 0, 0, ''),
(180, '', 'arvind', 'test@gmail.com', '45165464', '$2a$10$f9cf509e6338e6cfb02b3uad2I/9XzatJUhsXFfTj7j4WqnX5FG4u', 'adssad', '', 'FR', '2016-07-30 06:03:15', 0, '', 0, 0, ''),
(181, '', 'Thierry', 'thierry@yahoo.com', '57124425', '$2a$10$f319238bbe2548d18c417u1f.rA.N4FsPKyVjn05L8IAFy7h9r6oa', 'France', '', 'FR', '2016-10-05 07:54:58', 1, '', 0, 0, ''),
(182, '', 'Arvind', 'balgo_arvind@hotmail.com', '456453', '$2a$10$0ed39eec54fd145e9eab9OhRpQqa8hRvsWAij3t/GVlBjPK1emEoq', '453453', '', 'FR', '2016-10-23 16:37:01', 0, '', 0, 0, ''),
(183, '', '123456789', 'local@gmail.com', '123456789', '$2a$10$79e6137f87f208298355dOwTfG2TJ7BntYEu74sp4AcUY6dEu7sBa', '123456789', '', 'FR', '2016-10-26 00:26:30', 0, '', 0, 0, ''),
(184, '', 'Kirty', 'kirty@gmail.com', '675942', '$2a$10$55af9227d2b388e5bfbc5uQ3pMuLlFUF.ekKC7qEe8amahs5pqP5W', 'GB', '', 'FR', '2016-11-22 06:06:38', 1, '', 0, 0, ''),
(185, '', 'Vinita', 'vinita@gmail.com', '6175942', '$2a$10$85ca57b5e1a356467ec2fuLzwgev.d1kLCIOO0x18Mkt1zhk3vjTe', 'LBG', '', 'FR', '2016-11-28 14:16:58', 1, '', 0, 0, ''),
(186, '', 'LauraDeg', 'tgungaram@gmail.com', '32129349394', '$2a$10$35fb69da97ec3ad5b3646urW78zOVLbhd9NK7oqUF9qFTuJNP0UCK', '22 Rue Du Jardin', '', 'FR', '2017-03-09 18:15:14', 0, '', 0, 0, ''),
(187, '', 'operateur', 'operateur@exakom.fr', '58888888', '$2a$10$9900574e246752ad80f66O3icLyLIx01AQutZ4n/vXqZM/k2pw6xK', 'Candos Lane', 'Quatre Bornes', 'FR', '2017-07-04 03:55:24', 1, 'Exakom', 1, 0, ''),
(188, '', 'Thierry', 'contact@exakom.fr', '0183756043', '$2a$10$19d0559289ade089d8cd4uS0R8yVPzb0QBDP9TjU8nXVEGlv/X02.', 'Rue de la castellane', 'Paris', 'FR', '2017-07-12 07:37:47', 0, 'Jankee', 0, 75008, '82262433400014'),
(189, '', 'TEST', 'test132456@gmail.com', '1324567968', '$2a$10$7dc92896c603b9a605de3u0DqjQBHRj3j.4yj61klaetQ6FL6O1Xq', 'GB', '', 'AL', '2017-07-12 07:41:13', 0, 'TEST', 0, 0, ''),
(190, '', 'jankeee', 'papyrusdsg@orange.mu', '56', '$2a$10$e9c9fbce91b36534b7ffbuHfqxsGIkbN.meUOI8tLNO7MD23rre12', '', '', 'EN', '2017-07-17 12:57:46', 0, 'terry', 0, 0, ''),
(191, '', 'miguel', 'axeya@orange.mu', '0102030405', '$2a$10$7b5caa6d2124ad5cb93fauUlBJbR2Wh8WU8KGuEhD5776cPm.dgt6', '1 rue du bonheur', '', '', '2017-08-01 09:42:59', 0, 'duvivier', 0, 0, '63655+465+4');
