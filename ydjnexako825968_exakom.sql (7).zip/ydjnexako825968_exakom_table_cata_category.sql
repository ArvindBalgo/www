
CREATE TABLE `cata_category` (
  `id` int(11) NOT NULL,
  `libelle` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `color_code` text COLLATE utf8_unicode_ci NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cata_category` (`id`, `libelle`, `color_code`, `active`) VALUES
(7, 'Fleurs', '#9ec27f', 1),
(9, 'Design Vegetal et Espace vert', '#9ec27f', 1),
(10, 'Bouquets et Compositions', '#9ec27f', 1),
(14, 'Divers motif fleur & vÃ©gÃ©tal', '#9ec27f', 1),
(15, 'Mariage', '#ed93aa', 1),
(16, 'Deuil', '#9e8db4', 1),
(17, 'Fond', '#a19183', 1),
(18, 'Objets et decorations', '#a19183', 1),
(19, 'Coiffure', '#ca71a4', 1),
(20, 'Esthetique', '#7dd0dc', 1),
(21, 'Gastronomie', '#a5734b', 1),
(22, 'CÃ´tÃ© SucrÃ©', '#a5734b', 1),
(23, 'Ambiance de fÃªtes', '#e1a777', 1),
(24, 'Transmissions Florales', '#9ec27f', 1),
(25, 'Mode et Tendance', '#c879b2', 1),
(26, 'Enfant', '#ed93aa', 1),
(27, 'Cadre & LiserÃ©', '#a19183', 1),
(28, 'Bijoux', '#e1a777', 1),
(29, 'Logos de paiement', '#a19183', 1),
(30, 'Forme', '#a19183', 1),
(31, 'Language & Symbole', '', 1),
(32, 'Trait & FlÃ¨che', '', 1);
