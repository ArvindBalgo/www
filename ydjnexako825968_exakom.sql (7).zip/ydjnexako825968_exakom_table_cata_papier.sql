
CREATE TABLE `cata_papier` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8_unicode_ci NOT NULL,
  `description_es` text COLLATE utf8_unicode_ci NOT NULL,
  `description_al` text COLLATE utf8_unicode_ci NOT NULL,
  `description_it` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cata_papier` (`id`, `description`, `description_en`, `description_es`, `description_al`, `description_it`) VALUES
(6, 'CouchÃ© Classique 300Grs', 'Coated Paper 300Grs', 'Papel Estucado 300Grs', 'Beschichtetes Papier 300Grs', 'Carta patina 300Grs'),
(7, 'CouchÃ© 300Grs PelliculÃ© brillant recto', 'Coated Paper 300Grs Gloss Lamination front', 'Papel Estucado 300Grs Laminado Brillo anverso', 'Beschichtetes Papier 300Grs Folienkaschierung GlÃ¤nzend vorderseite', 'Carta patina 300Grs Plastificazione Lucido fronte'),
(8, 'CouchÃ© 300Grs PelliculÃ© brillant recto verso', 'Coated Paper 300Grs Gloss Lamination front/back', 'Papel Estucado 300Grs Laminado Brillo anverso y reverso', 'Beschichtetes Papier 300Grs Folienkaschierung GlÃ¤nzend Vorder- und RÃ¼ckseite', 'Carta patina 300Grs Plastificazione Lucido Fronte/Retro'),
(9, 'CouchÃ© 300Grs PelliculÃ© mat recto verso', 'Coated Paper 300Grs Matt Lamination front/back', 'Papel Estucado 300Grs Laminado Mate anverso y reverso', 'Beschichtetes Papier 300Grs Folienkaschierung Matt Vorder- und RÃ¼ckseite', 'Carta patina 300Grs Plastificazione Opaco Fronte/Retro'),
(10, 'CouchÃ© 300Grs PelliculÃ© mat recto verso avec vernis sÃ©lectif', 'Coated Paper 300Grs Matt Lamination front/back + Spot coating', 'Papel Estucado 300Grs Laminado Mate anverso y reverso + Barniz reserva', 'Folienkaschierung Matt Vorder- und RÃ¼ckseite + Partieller Lack', 'Carta patina 300Grs Plastificazione Opaco Fronte/Retro + Vernice selettiva'),
(11, 'Papier Offset 90 grs', 'Classic Paper 90G', 'Papel Offset 90G', 'Offset Papier 90G', 'Usomano 90G'),
(12, 'VergÃ©', 'Laid Paper', 'Verjurado', 'Laid Papier', 'Vergato'),
(13, 'Kit ParfumÃ©', 'Perfume Kit', 'Perfume Kit', 'Perfume Kit', 'Perfume Kit'),
(15, 'CouchÃ© Vernis Brillant', 'Gloss Coating Coated Paper', 'Papel Estucado Barniz Brillo', 'Lack glÃ¤nzend Beschichtetes Papier', 'Carta patina Vernice Lucido'),
(16, 'Kraft', 'Kraft', 'Kraft', 'Kraft', 'Kraft');
