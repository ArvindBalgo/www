
CREATE TABLE `coupon_details` (
  `id` int(11) NOT NULL,
  `id_coupon` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `email` text NOT NULL,
  `flag` text NOT NULL,
  `date_used` date NOT NULL,
  `id_order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `coupon_details` (`id`, `id_coupon`, `id_user`, `email`, `flag`, `date_used`, `id_order`) VALUES
(25, 3, 179, 'balgo_arvind@hotmail.com', 'UNUSED', '2017-07-31', 0),
(26, 3, 180, 'test@gmail.com', 'UNUSED', '2017-07-31', 0),
(27, 3, 181, 'thierry@yahoo.com', 'UNUSED', '2017-07-31', 0),
(28, 3, 182, 'balgo_arvind@hotmail.com', 'UNUSED', '2017-07-31', 0),
(29, 3, 183, 'local@gmail.com', 'UNUSED', '2017-07-31', 0),
(30, 3, 184, 'kirty@gmail.com', 'UNUSED', '2017-07-31', 0),
(31, 3, 185, 'vinita@gmail.com', 'UNUSED', '2017-07-31', 0),
(32, 3, 186, 'tgungaram@gmail.com', 'UNUSED', '2017-07-31', 0),
(33, 3, 187, 'operateur@exakom.fr', 'UNUSED', '2017-07-31', 0),
(34, 3, 188, 'contact@exakom.fr', 'UNUSED', '2017-07-31', 0),
(35, 3, 189, 'test132456@gmail.com', 'UNUSED', '2017-07-31', 0),
(36, 3, 190, 'papyrusdsg@orange.mu', 'UNUSED', '2017-07-31', 0);
