
CREATE TABLE `listmetier` (
  `id` int(11) NOT NULL,
  `libelle` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `libelle_en` text COLLATE utf8_unicode_ci NOT NULL,
  `libelle_es` text COLLATE utf8_unicode_ci NOT NULL,
  `libelle_it` text COLLATE utf8_unicode_ci NOT NULL,
  `libelle_al` text COLLATE utf8_unicode_ci NOT NULL,
  `sub_libelle` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `sub_libelle_en` text COLLATE utf8_unicode_ci NOT NULL,
  `sub_libelle_es` text COLLATE utf8_unicode_ci NOT NULL,
  `sub_libelle_al` text COLLATE utf8_unicode_ci NOT NULL,
  `sub_libelle_it` text COLLATE utf8_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `pays` int(11) NOT NULL DEFAULT '1',
  `key_libelle` text COLLATE utf8_unicode_ci NOT NULL,
  `key_sub_libelle` text COLLATE utf8_unicode_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `listmetier` (`id`, `libelle`, `libelle_en`, `libelle_es`, `libelle_it`, `libelle_al`, `sub_libelle`, `sub_libelle_en`, `sub_libelle_es`, `sub_libelle_al`, `sub_libelle_it`, `active`, `pays`, `key_libelle`, `key_sub_libelle`, `date_created`, `date_modified`) VALUES
(14, 'Fleur et vÃ©gÃ©tal', 'Flower & Vegetal', 'Flores y Plantas', 'Fiori e Piante', 'Blumen und Pflanzen', '', '', '', '', '', 1, 1, 'fleur_vegetal', '', '2017-02-10 06:13:55', '2017-02-10 06:12:13'),
(16, 'CÃ´tÃ© SucrÃ©', 'Sweet Way', 'Lado Azucarado', 'Sapore Dolce', 'SÃ¼ÃŸer Geschmack', '', '', '', '', '', 1, 1, 'cote_sucre', '', '2017-02-10 07:20:02', '2017-02-10 07:18:53'),
(17, 'GoÃ»t & Gastronomie', 'Food & Wine', 'Gusto y GastronomÃ­a', 'Gusto e Gastronomia', 'Gastronomie', '', '', '', '', '', 1, 1, 'gout_gastronomie', '', '2017-02-10 07:20:02', '2017-02-10 07:19:19'),
(21, 'Soins & BeautÃ©', 'Beauty & Spa', 'Cuidados y Belleza', 'Spa e Bellezza', 'Pflege und SchÃ¶nheit', '', '', '', '', '', 1, 1, 'soins_beaute', '', '2017-02-10 07:20:02', '2017-02-10 07:19:07'),
(22, 'Mode & Tendance', 'Fashion & Lifestyle', 'Moda y Tendencia', 'La moda e Tendenze', 'Mode und Trend', '', '', '', '', '', 1, 1, 'mode_tendance', '', '2017-02-10 07:20:02', '2017-02-10 07:19:28'),
(23, 'FunÃ©raire', 'Funeral', 'Funerario', 'Funerario', 'Bestattung', '', '', '', '', '', 1, 1, 'funeraire_...', '', '2017-02-10 12:28:19', '2017-02-10 12:28:19');
