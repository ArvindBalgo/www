
CREATE TABLE `instructions_en` (
  `id` int(11) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `instructions_en` (`id`, `instruction`) VALUES
(1, 'Create your free customized artwork.'),
(2, 'Find your business and your product, enter in your creation espace.'),
(3, 'Once you map your product, our experienced graphic designers will work your artwork in the most effective and unique way and send it to you within 2 working days.'),
(4, 'Upload your photos, logos, draft designs, we will design your project from a simple idea or from your partially designed concept.'),
(5, 'Our photo Gallery, artwork design, logos 100 % Free'),
(6, 'Our sole objective: Customer satisfaction.'),
(7, 'Rely on Exakom');
