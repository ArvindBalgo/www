
CREATE TABLE `pub` (
  `id` int(11) NOT NULL,
  `actif` int(11) NOT NULL,
  `pays` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `pub` (`id`, `actif`, `pays`, `link`) VALUES
(2, 1, 'FR', 'assets/pubs/french-banner.jpg'),
(3, 1, 'EN', 'assets/pubs/english-banner.jpg'),
(4, 1, 'AL', 'assets/pubs/allemand-banner.jpg'),
(5, 1, 'ES', 'assets/pubs/Espagnol-banner.jpg'),
(6, 1, 'IT', 'assets/pubs/italian-banner2.jpg');
