
CREATE TABLE `coupon_main` (
  `id` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `coupon_code` text NOT NULL,
  `val` float NOT NULL,
  `emailing_flag` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `coupon_main` (`id`, `date_start`, `date_end`, `coupon_code`, `val`, `emailing_flag`) VALUES
(3, '2017-07-05', '2017-08-23', 'EXA50KOM', 50, 1);
