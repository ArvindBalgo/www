
-- --------------------------------------------------------

--
-- Table structure for table `instructions_al`
--

CREATE TABLE `instructions_al` (
  `id` int(11) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructions_al`
--

INSERT INTO `instructions_al` (`id`, `instruction`) VALUES
(1, 'Machen Sie Ihr lay-out frei'),
(2, 'WÃ¤hlen Sie Ihr feld und Ihr Produkt, fÃ¼gen Sie es Ihnen Kreativ Raum ein.'),
(3, 'Ihr Produkt wird innerhalb von us studen bearbeitet.'),
(4, 'Uploaden Sie Ihre Fotos, Logos, layouts, wir realisieren Ihre Projekte.'),
(5, 'Fotos, layouts, logos 100% gratis'),
(6, 'Unser alleiniges Ziel ist Ihre Zufriedenheit'),
(7, '* Siehe Bestell Bedingungen in den.');
