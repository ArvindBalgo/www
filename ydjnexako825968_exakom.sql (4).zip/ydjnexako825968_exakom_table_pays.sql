
-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE `pays` (
  `id` int(11) NOT NULL,
  `libelle` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `abrev` varchar(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pays`
--

INSERT INTO `pays` (`id`, `libelle`, `abrev`) VALUES
(1, 'FRANCAIS', 'FR'),
(2, 'ENGLISH', 'EN'),
(3, 'ESPANOL', 'ES'),
(4, 'DEUTSCH', 'AL'),
(5, 'ITALIANO', 'IT');
