
-- --------------------------------------------------------

--
-- Table structure for table `cata_papier`
--

CREATE TABLE `cata_papier` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8_unicode_ci NOT NULL,
  `description_es` text COLLATE utf8_unicode_ci NOT NULL,
  `description_al` text COLLATE utf8_unicode_ci NOT NULL,
  `description_it` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cata_papier`
--

INSERT INTO `cata_papier` (`id`, `description`, `description_en`, `description_es`, `description_al`, `description_it`) VALUES
(6, 'CouchÃ© Classique', 'Coated Paper', 'Papel Estucado', 'Beschichtetes Papier', 'Carta patina'),
(7, 'CouchÃ© PelliculÃ© brillant recto', 'Gloss Lamination front', 'Laminado Brillo anverso', 'Folienkaschierung GlÃ¤nzend vorderseite', 'Plastificazione Lucido fronte'),
(8, 'CouchÃ© PelliculÃ© brillant recto verso', 'Gloss Lamination front/back', 'Laminado Brillo anverso y reverso', 'Folienkaschierung GlÃ¤nzend Vorder- und RÃ¼ckseite', 'Plastificazione Lucido Fronte/Retro'),
(9, 'CouchÃ© PelliculÃ© mat recto verso', 'Matt Lamination front/back', 'Laminado Mate anverso y reverso', 'Folienkaschierung Matt Vorder- und RÃ¼ckseite', 'Plastificazione Opaco Fronte/Retro'),
(10, 'CouchÃ© PelliculÃ© mat recto verso avec vernis sÃ©lectif', 'Matt Lamination front/back + Spot coating', 'Laminado Mate anverso y reverso + Barniz reserva', 'Folienkaschierung Matt Vorder- und RÃ¼ckseite + Partieller Lack', 'Plastificazione Opaco Fronte/Retro + Vernice selettiva'),
(11, 'Papier Offset 90 grs', 'Classic Paper 90G', 'Papel Offset 90G', 'Offset Papier 90G', 'Usomano 90G'),
(12, 'VergÃ©', 'Laid Paper', 'Verjurado', 'Laid Papier', 'Vergato'),
(13, 'Kit ParfumÃ©', 'Perfume Kit', 'Perfume Kit', 'Perfume Kit', 'Perfume Kit'),
(15, 'CouchÃ© Vernis Brillant', 'Gloss Coating Coated Paper', 'Papel Estucado Barniz Brillo', 'Lack glÃ¤nzend Beschichtetes Papier', 'Carta patina Vernice Lucido'),
(16, 'Kraft', 'Kraft', 'Kraft', 'Kraft', 'Kraft');
