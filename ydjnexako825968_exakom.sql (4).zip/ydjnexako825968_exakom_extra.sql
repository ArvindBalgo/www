
--
-- Indexes for dumped tables
--

--
-- Indexes for table `apropos`
--
ALTER TABLE `apropos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_al`
--
ALTER TABLE `apropos_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_en`
--
ALTER TABLE `apropos_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_es`
--
ALTER TABLE `apropos_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_it`
--
ALTER TABLE `apropos_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata`
--
ALTER TABLE `cata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catalogue`
--
ALTER TABLE `catalogue`
  ADD PRIMARY KEY (`id_catalogue`);

--
-- Indexes for table `cata_category`
--
ALTER TABLE `cata_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_dimension`
--
ALTER TABLE `cata_dimension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_image`
--
ALTER TABLE `cata_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_ligne`
--
ALTER TABLE `cata_ligne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_ligne_params`
--
ALTER TABLE `cata_ligne_params`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_metier`
--
ALTER TABLE `cata_metier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_papier`
--
ALTER TABLE `cata_papier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_support`
--
ALTER TABLE `cata_support`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coeff_prix`
--
ALTER TABLE `coeff_prix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande_ligne`
--
ALTER TABLE `commande_ligne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande_ligne_params`
--
ALTER TABLE `commande_ligne_params`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente`
--
ALTER TABLE `conditionvente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_al`
--
ALTER TABLE `conditionvente_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_en`
--
ALTER TABLE `conditionvente_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_es`
--
ALTER TABLE `conditionvente_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_it`
--
ALTER TABLE `conditionvente_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers_auth`
--
ALTER TABLE `customers_auth`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `docs`
--
ALTER TABLE `docs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_al`
--
ALTER TABLE `docs_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_en`
--
ALTER TABLE `docs_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_es`
--
ALTER TABLE `docs_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_it`
--
ALTER TABLE `docs_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frais_livraison`
--
ALTER TABLE `frais_livraison`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gabarits`
--
ALTER TABLE `gabarits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions`
--
ALTER TABLE `instructions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_al`
--
ALTER TABLE `instructions_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_en`
--
ALTER TABLE `instructions_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_es`
--
ALTER TABLE `instructions_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_it`
--
ALTER TABLE `instructions_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `langue`
--
ALTER TABLE `langue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listmetier`
--
ALTER TABLE `listmetier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modelmetier`
--
ALTER TABLE `modelmetier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modelmetier_category`
--
ALTER TABLE `modelmetier_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_main`
--
ALTER TABLE `orders_main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `polices`
--
ALTER TABLE `polices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pub`
--
ALTER TABLE `pub`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sample`
--
ALTER TABLE `sample`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `souscategory_coeffprix`
--
ALTER TABLE `souscategory_coeffprix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tarif_manuel`
--
ALTER TABLE `tarif_manuel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `temp_prod`
--
ALTER TABLE `temp_prod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tva`
--
ALTER TABLE `tva`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apropos`
--
ALTER TABLE `apropos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `apropos_al`
--
ALTER TABLE `apropos_al`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `apropos_en`
--
ALTER TABLE `apropos_en`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `apropos_es`
--
ALTER TABLE `apropos_es`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `apropos_it`
--
ALTER TABLE `apropos_it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cata`
--
ALTER TABLE `cata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2262;
--
-- AUTO_INCREMENT for table `cata_category`
--
ALTER TABLE `cata_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `cata_dimension`
--
ALTER TABLE `cata_dimension`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2663;
--
-- AUTO_INCREMENT for table `cata_image`
--
ALTER TABLE `cata_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1920;
--
-- AUTO_INCREMENT for table `cata_ligne`
--
ALTER TABLE `cata_ligne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6112;
--
-- AUTO_INCREMENT for table `cata_ligne_params`
--
ALTER TABLE `cata_ligne_params`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17164;
--
-- AUTO_INCREMENT for table `cata_metier`
--
ALTER TABLE `cata_metier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3600;
--
-- AUTO_INCREMENT for table `cata_papier`
--
ALTER TABLE `cata_papier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `cata_support`
--
ALTER TABLE `cata_support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `coeff_prix`
--
ALTER TABLE `coeff_prix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12744;
--
-- AUTO_INCREMENT for table `commande`
--
ALTER TABLE `commande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `commande_ligne`
--
ALTER TABLE `commande_ligne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `commande_ligne_params`
--
ALTER TABLE `commande_ligne_params`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `conditionvente`
--
ALTER TABLE `conditionvente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `conditionvente_al`
--
ALTER TABLE `conditionvente_al`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `conditionvente_en`
--
ALTER TABLE `conditionvente_en`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `conditionvente_es`
--
ALTER TABLE `conditionvente_es`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `conditionvente_it`
--
ALTER TABLE `conditionvente_it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `customers_auth`
--
ALTER TABLE `customers_auth`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT for table `docs`
--
ALTER TABLE `docs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `docs_al`
--
ALTER TABLE `docs_al`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `docs_en`
--
ALTER TABLE `docs_en`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `docs_es`
--
ALTER TABLE `docs_es`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `docs_it`
--
ALTER TABLE `docs_it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `frais_livraison`
--
ALTER TABLE `frais_livraison`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127176;
--
-- AUTO_INCREMENT for table `gabarits`
--
ALTER TABLE `gabarits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `instructions`
--
ALTER TABLE `instructions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `instructions_al`
--
ALTER TABLE `instructions_al`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `instructions_en`
--
ALTER TABLE `instructions_en`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `instructions_es`
--
ALTER TABLE `instructions_es`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `instructions_it`
--
ALTER TABLE `instructions_it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `langue`
--
ALTER TABLE `langue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2224;
--
-- AUTO_INCREMENT for table `listmetier`
--
ALTER TABLE `listmetier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `modelmetier`
--
ALTER TABLE `modelmetier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT for table `modelmetier_category`
--
ALTER TABLE `modelmetier_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;
--
-- AUTO_INCREMENT for table `orders_details`
--
ALTER TABLE `orders_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `orders_main`
--
ALTER TABLE `orders_main`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `pays`
--
ALTER TABLE `pays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `polices`
--
ALTER TABLE `polices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- AUTO_INCREMENT for table `pub`
--
ALTER TABLE `pub`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `sample`
--
ALTER TABLE `sample`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `souscategory_coeffprix`
--
ALTER TABLE `souscategory_coeffprix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=454;
--
-- AUTO_INCREMENT for table `tarif_manuel`
--
ALTER TABLE `tarif_manuel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=242472;
--
-- AUTO_INCREMENT for table `temp_prod`
--
ALTER TABLE `temp_prod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;
--
-- AUTO_INCREMENT for table `tva`
--
ALTER TABLE `tva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;