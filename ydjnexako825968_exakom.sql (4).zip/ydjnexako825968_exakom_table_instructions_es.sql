
-- --------------------------------------------------------

--
-- Table structure for table `instructions_es`
--

CREATE TABLE `instructions_es` (
  `id` int(11) NOT NULL,
  `instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructions_es`
--

INSERT INTO `instructions_es` (`id`, `instruction`) VALUES
(1, 'Realise vuestra maqueta o proyecto gratuitamente'),
(2, 'Usted elige vuestra actividad y vuestro producto, entre al espacio creaciÃ³n'),
(3, 'Esquematizar vuestra maqueta, esta serÃ¡ tratada por nuestros grafistas en 48 horas'),
(4, 'Descargue vuestras fotos, logotipos, maquetas y nosotros realizamos vuestros proyectos'),
(5, 'Banco de imÃ¡genes, maquetas, logos 100% gratis'),
(6, 'Nuestro Ãºnico objetivo: vuestra satisfacciÃ³n!'),
(7, 'Exakom en toda confianza');
