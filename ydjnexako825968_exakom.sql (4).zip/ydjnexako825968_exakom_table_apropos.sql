
-- --------------------------------------------------------

--
-- Table structure for table `apropos`
--

CREATE TABLE `apropos` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apropos`
--

INSERT INTO `apropos` (`id`, `description`) VALUES
(1, 'L\'informatique en gÃ©nÃ©ral et Internet en particulier rÃ©volutionne nos mÃ©tiers en permettant de considÃ©rables Ã©conomies de structure dont Exakom entend bien vous faire profiter.\nVous aurez des produits de trÃ¨s haute qualitÃ© avec des prix trÃ¨s compÃ©titifs, vous payez le \"juste\" prix. Ce n\'est pas du low cost, c\'est juste du bon sens!\nNous commercialisons uniquement les produits parfaitement connus de vous, ils ne nÃ©cessitent pas la prÃ©sence d\'une force de vente.\nNous prÃ©servons ainsi notre environnement en Ã©vitant des millions de kilomÃ¨tres parcourus annuellement par celle-ci.\nNous avons dÃ©veloppÃ© un systÃ¨me qui automatise au maximum l\'ensemble des tÃ¢ches, toutefois nous sommes Ã   votre disposition pour vous conseiller et vous accompagner dans vos projets.\nNotre objectif c\'est votre entiÃ¨re satisfaction et la prÃ©servation de notre environnement.');
