
-- --------------------------------------------------------

--
-- Table structure for table `pub`
--

CREATE TABLE `pub` (
  `id` int(11) NOT NULL,
  `actif` int(11) NOT NULL,
  `pays` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pub`
--

INSERT INTO `pub` (`id`, `actif`, `pays`, `link`) VALUES
(2, 1, 'FR', 'assets/pubs/FRENCH-banner.jpg'),
(3, 1, 'EN', 'assets/pubs/eng-banner2.jpg'),
(4, 1, 'AL', 'assets/pubs/banner-allemand.jpg'),
(5, 1, 'ES', 'assets/pubs/banner-espagnol.jpg'),
(6, 1, 'IT', 'assets/pubs/banner-italien.jpg');
