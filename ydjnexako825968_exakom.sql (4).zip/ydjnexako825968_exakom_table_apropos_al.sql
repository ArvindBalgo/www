
-- --------------------------------------------------------

--
-- Table structure for table `apropos_al`
--

CREATE TABLE `apropos_al` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apropos_al`
--

INSERT INTO `apropos_al` (`id`, `description`) VALUES
(1, 'IT im Allgemeinen und Internet hat vor allem, indem sie erhebliche Einsparungen unsere GeschÃ¤ftsstruktur revolutioniert die Exakom Sie genieÃŸen machen will. Sie werden mit sehr konkurrenzfÃ¤higen Preis, qualitativ hochwertige Produkte haben, zahlen Sie endlich den \"richtigen\" Preis.\nWir verkaufen nur die Produkte gut zu Ihnen bekannt, sie erfordern nicht die Anwesenheit einer Sales Force. Wir erhalten somit unsere Umwelt von Millionen von Kilometern jÃ¤hrlich um es zu vermeiden.\nWir haben ein System entwickelt, das die maximale alle Aufgaben automatisiert, aber wir sind hier, um zu beraten und Ihnen bei Ihren Projekten unterstÃ¼tzen.\nUnser Ziel ist Ihre Zufriedenheit und Erhaltung unserer Umwelt.');
