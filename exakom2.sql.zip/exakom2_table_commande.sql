
-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

CREATE TABLE `commande` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `addon` int(11) NOT NULL,
  `dimension` text NOT NULL,
  `quantite` int(11) NOT NULL,
  `commentaire` int(11) NOT NULL,
  `prix` int(11) NOT NULL,
  `id_front` int(11) NOT NULL,
  `id_back` int(11) NOT NULL,
  `src` text NOT NULL,
  `bonrepli` int(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `createdon` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `commande`
--

INSERT INTO `commande` (`id`, `title`, `addon`, `dimension`, `quantite`, `commentaire`, `prix`, `id_front`, `id_back`, `src`, `bonrepli`, `createdby`, `createdon`) VALUES
(1, '', 0, '22+10X29 CM (L+PXH)', 1, 0, 0, 1, 2, 'images/flat_images/product_1477722702.png', 1, 181, '2016-10-29 02:31:42'),
(2, '', 0, '', 1, 0, 0, 3, 4, 'images/flat_images/product_1477797476.png', 1, 182, '2016-10-29 23:17:56');
