
-- --------------------------------------------------------

--
-- Table structure for table `apropos_es`
--

CREATE TABLE `apropos_es` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apropos_es`
--

INSERT INTO `apropos_es` (`id`, `description`) VALUES
(1, 'La informatica en general e internet en particular revoluciona nuestros trabajos permanentemente considerables economÃ­as de estructura que Exakon le ofrece para vuestro provecho. Usted tendrÃ¡ producctos de muy alta cantidad con precios muy competitivos, (vous payez le juste prix)\nExakom comercializa unicamente los productos perfectamente que usted conoce, no necesitan la presencia de una fuerza de venta. Preservando asi nuestro medio ambiente.\nExakom ha desarrollado un sistema que automatisa al maximo el conjunto de tareas. A la vez estamos a vuestra disposiciÃ³n para aconsejarle y acompaÃ±arle en vuestros proyectos.\nNuestro objetivo es vuestra entera satisfaction y preservation del medio ambiente.');
