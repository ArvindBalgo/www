
-- --------------------------------------------------------

--
-- Table structure for table `orders_main`
--

CREATE TABLE `orders_main` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `total_livraison_ht` float NOT NULL,
  `total_livraison_ttc` float NOT NULL,
  `total_prix_ht` float NOT NULL,
  `total_prix_ttc` float NOT NULL,
  `tax` float NOT NULL,
  `total_prix_net` float NOT NULL,
  `status` text NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_main`
--

INSERT INTO `orders_main` (`id`, `id_user`, `total_livraison_ht`, `total_livraison_ttc`, `total_prix_ht`, `total_prix_ttc`, `tax`, `total_prix_net`, `status`, `date_created`, `date_modified`, `created_by`, `modified_by`, `comments`) VALUES
(36, 182, 7.75, 9.3, 191, 229.2, 38.2, 0, 'IMPRESSION', '2017-07-02 09:51:31', '2017-07-03 14:40:14', 182, 179, ''),
(37, 179, 7.75, 9.3, 174, 208.8, 34.8, 0, 'BON_TIRER', '2017-07-03 12:20:22', '2017-07-03 12:35:50', 179, 179, ''),
(38, 179, 7.75, 9.3, 174, 208.8, 34.8, 0, 'PELLICULAGE_VERNISSAGE', '2017-07-03 12:28:13', '2017-07-03 14:40:19', 179, 179, ''),
(39, 179, 7.75, 9.3, 174, 208.8, 34.8, 0, 'ARCHIEVE', '2017-07-03 12:29:15', '2017-07-03 12:36:43', 179, 179, ''),
(40, 182, 15.5, 18.6, 348.5, 418.2, 69.7, 0, 'BON_TIRER', '2017-07-05 01:43:37', '2017-07-10 00:13:52', 182, 179, ''),
(41, 182, 15.5, 18.6, 348.5, 418.2, 69.7, 0, 'MONTAGE_MAQUETTE', '2017-07-05 01:43:43', '2017-07-10 00:14:00', 182, 179, ''),
(42, 182, 15.5, 18.6, 348.5, 418.2, 69.7, 0, 'IMPRESSION', '2017-07-05 01:43:52', '2017-07-10 00:14:08', 182, 179, ''),
(43, 182, 15.5, 18.6, 348.5, 418.2, 69.7, 0, 'PELLICULAGE_VERNISSAGE', '2017-07-05 01:43:58', '2017-07-10 00:14:14', 182, 179, ''),
(44, 182, 15.5, 18.6, 348.5, 418.2, 69.7, 0, 'PELLICULAGE_VERNISSAGE', '2017-07-05 01:44:03', '2017-07-10 00:14:21', 182, 179, ''),
(45, 182, 7.75, 9.3, 191, 229.2, 38.2, 0, 'IMPRESSION', '2017-07-06 02:27:51', '2017-07-10 00:14:29', 182, 179, ''),
(46, 179, 0, 0, 0, 0, 0, 0, 'MONTAGE_MAQUETTE', '2017-07-10 00:15:08', '2017-07-10 00:16:07', 179, 179, ''),
(47, 179, 0, 0, 0, 0, 0, 0, 'PELLICULAGE_VERNISSAGE', '2017-07-10 00:15:10', '2017-07-10 00:16:16', 179, 179, ''),
(48, 179, 0, 0, 0, 0, 0, 0, 'REJECT', '2017-07-10 00:16:46', '2017-07-10 00:18:14', 179, 179, ''),
(49, 179, 0, 0, 0, 0, 0, 0, 'REJECT', '2017-07-10 00:16:46', '2017-07-10 00:18:24', 179, 179, ''),
(50, 179, 0, 0, 0, 0, 0, 0, 'NEW', '2017-07-10 00:21:59', '2017-07-10 00:21:59', 179, 179, '');
