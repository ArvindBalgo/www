
--
-- Indexes for dumped tables
--

--
-- Indexes for table `apropos`
--
ALTER TABLE `apropos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_al`
--
ALTER TABLE `apropos_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_en`
--
ALTER TABLE `apropos_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_es`
--
ALTER TABLE `apropos_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apropos_it`
--
ALTER TABLE `apropos_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata`
--
ALTER TABLE `cata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catalogue`
--
ALTER TABLE `catalogue`
  ADD PRIMARY KEY (`id_catalogue`);

--
-- Indexes for table `cata_category`
--
ALTER TABLE `cata_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_dimension`
--
ALTER TABLE `cata_dimension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_image`
--
ALTER TABLE `cata_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_ligne`
--
ALTER TABLE `cata_ligne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_ligne_params`
--
ALTER TABLE `cata_ligne_params`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_metier`
--
ALTER TABLE `cata_metier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_papier`
--
ALTER TABLE `cata_papier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cata_support`
--
ALTER TABLE `cata_support`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coeff_prix`
--
ALTER TABLE `coeff_prix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande_ligne`
--
ALTER TABLE `commande_ligne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commande_ligne_params`
--
ALTER TABLE `commande_ligne_params`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente`
--
ALTER TABLE `conditionvente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_al`
--
ALTER TABLE `conditionvente_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_en`
--
ALTER TABLE `conditionvente_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_es`
--
ALTER TABLE `conditionvente_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditionvente_it`
--
ALTER TABLE `conditionvente_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers_auth`
--
ALTER TABLE `customers_auth`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `docs`
--
ALTER TABLE `docs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_al`
--
ALTER TABLE `docs_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_en`
--
ALTER TABLE `docs_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_es`
--
ALTER TABLE `docs_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `docs_it`
--
ALTER TABLE `docs_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frais_livraison`
--
ALTER TABLE `frais_livraison`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gabarits`
--
ALTER TABLE `gabarits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions`
--
ALTER TABLE `instructions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_al`
--
ALTER TABLE `instructions_al`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_en`
--
ALTER TABLE `instructions_en`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_es`
--
ALTER TABLE `instructions_es`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructions_it`
--
ALTER TABLE `instructions_it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `langue`
--
ALTER TABLE `langue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listmetier`
--
ALTER TABLE `listmetier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modelmetier`
--
ALTER TABLE `modelmetier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modelmetier_category`
--
ALTER TABLE `modelmetier_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_main`
--
ALTER TABLE `orders_main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `polices`
--
ALTER TABLE `polices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pub`
--
ALTER TABLE `pub`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sample`
--
ALTER TABLE `sample`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `souscategory_coeffprix`
--
ALTER TABLE `souscategory_coeffprix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tarif_manuel`
--
ALTER TABLE `tarif_manuel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `temp_prod`
--
ALTER TABLE `temp_prod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tva`
--
ALTER TABLE `tva`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers_auth`
--
ALTER TABLE `customers_auth`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;
--
-- AUTO_INCREMENT for table `orders_details`
--
ALTER TABLE `orders_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `orders_main`
--
ALTER TABLE `orders_main`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `temp_prod`
--
ALTER TABLE `temp_prod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;