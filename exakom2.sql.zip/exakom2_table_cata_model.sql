
-- --------------------------------------------------------

--
-- Table structure for table `cata_model`
--

CREATE TABLE `cata_model` (
  `id_model` int(11) NOT NULL,
  `id_cata` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
