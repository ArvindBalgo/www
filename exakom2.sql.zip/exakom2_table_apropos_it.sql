
-- --------------------------------------------------------

--
-- Table structure for table `apropos_it`
--

CREATE TABLE `apropos_it` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apropos_it`
--

INSERT INTO `apropos_it` (`id`, `description`) VALUES
(1, 'L\'informatica in generale e Internet in particolare, hanno rivoluzionato il nostro mestiere permettendo dei considerevoli risparmi dei quali Exakom vuole farvi approfittare. Voi avrete dei prodotti di alta qualitÃ  a dei prezzi molto competitivi, infine pegherete il giusto prezzo.\nNoi commercializziamo solo i prodotti che conoscete perfettamente senza aver bisogno di una forza vendita e cosÃ¬ facendo preserveremo anche l\'ambiente evitando migliaia di chilometri percorsi annualmente da quest\'ultimi, noi abbiamo sviluppato un sistema che automatizza a l massimo l\'insieme delle dei processi di vendita, in ogni caso noi siamo a completa disposizione per consigliarvi e ad accompagnarvi nei vostri progetti, il nostro principale obbiettivo Ã¨ la vostra completa soddisfazione e la preservazione del nostro ambiente.');
