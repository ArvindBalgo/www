
-- --------------------------------------------------------

--
-- Table structure for table `gabarits`
--

CREATE TABLE `gabarits` (
  `id` int(11) NOT NULL,
  `id_modelmetier` int(11) NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `src` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `id_sample` int(11) NOT NULL,
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
