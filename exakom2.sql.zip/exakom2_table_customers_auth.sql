
-- --------------------------------------------------------

--
-- Table structure for table `customers_auth`
--

CREATE TABLE `customers_auth` (
  `uid` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pays` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'FR',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` int(11) NOT NULL DEFAULT '0',
  `surname` text COLLATE utf8_unicode_ci NOT NULL,
  `postalcode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `admintype` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers_auth`
--

INSERT INTO `customers_auth` (`uid`, `name`, `email`, `phone`, `password`, `address`, `city`, `pays`, `created`, `admin`, `surname`, `postalcode`, `admintype`) VALUES
(169, 'Swadesh Behera', 'swadesh@gmail.com', '1234567890', '$2a$10$251b3c3d020155f7553c1ugKfEH04BD6nbCbo78AIDVOqS3GVYQ46', '4092 Furth Circle', 'Singapore', 'FR', '2014-08-31 08:21:20', 0, 'Swadesh Behera', '12465', 0),
(170, 'Ipsita Sahoo', 'ipsita@gmail.com', '1111111111', '$2a$10$d84ffcf46967db4e1718buENHT7GVpcC7FfbSqCLUJDkKPg4RcgV2', '2, rue du Commerce', 'NYC', 'FR', '2014-08-31 08:30:58', 0, 'Ipsita Sahoo', '12465', 0),
(171, 'Trisha Tamanna Priyadarsini', 'trisha@gmail.com', '2222222222', '$2a$10$c9b32f5baa3315554bffcuWfjiXNhO1Rn4hVxMXyJHJaesNHL9U/O', 'C/ Moralzarzal, 86', 'Burlingame', 'FR', '2014-08-31 08:32:03', 1, 'Trisha Tamanna Priyadarsini', '12465', 0),
(172, 'Sai Rimsha', 'rimsha@gmail.com', '3333333333', '$2a$10$477f7567571278c17ebdees5xCunwKISQaG8zkKhvfE5dYem5sTey', '897 Long Airport Avenue', 'Madrid', 'FR', '2014-08-31 10:34:21', 0, 'Sai Rimsha', '12465', 0),
(173, 'Satwik Mohanty', 'satwik@gmail.com', '4444444444', '$2a$10$2b957be577db7727fed13O2QmHMd9LoEUjioYe.zkXP5lqBumI6Dy', 'Lyonerstr. 34', 'San Francisco\n', 'FR', '2014-08-31 10:36:02', 0, 'Satwik Mohanty', '12465', 0),
(174, 'Tapaswini Sahoo', 'linky@gmail.com', '5555555555', '$2a$10$b2f3694f56fdb5b5c9ebeulMJTSx2Iv6ayQR0GUAcDsn0Jdn4c1we', 'ul. Filtrowa 68', 'Warszawa', 'FR', '2014-08-31 10:44:54', 0, 'Tapaswini Sahoo', '12465', 0),
(175, 'Manas Ranjan Subudhi', 'manas@gmail.com', '6666666666', '$2a$10$03ab40438bbddb67d4f13Odrzs6Rwr92xKEYDbOO7IXO8YvBaOmlq', '5677 Strong St.', 'Stavern\n', 'FR', '2014-08-31 10:45:08', 0, 'Manas Ranjan Subudhi', '12465', 0),
(178, 'AngularCode Administrator', 'admin@angularcode.com', '0000000000', '$2a$10$72442f3d7ad44bcf1432cuAAZAURj9dtXhEMBQXMn9C8SpnZjmK1S', 'C/1052, Bangalore', '', 'FR', '2014-08-31 11:00:26', 0, 'AngularCode Administrator', '12465', 0),
(179, 'Arvind', 'balgo_arvind@hotmail.com', '59125334', '$2a$10$e80dbf222f1288ddf527duE7AvmS5PnfSjPsxS6Fi5A7X9673n6T2', 'Gbois', '', 'FR', '2016-07-13 12:46:50', 1, 'Arvind', '12465', 0),
(180, 'arvind', 'test@gmail.com', '45165464', '$2a$10$f9cf509e6338e6cfb02b3uad2I/9XzatJUhsXFfTj7j4WqnX5FG4u', 'adssad', '', 'FR', '2016-07-30 02:03:15', 0, 'arvind', '12465', 0),
(181, 'Thierry', 'thierry@yahoo.com', '57124425', '$2a$10$f319238bbe2548d18c417u1f.rA.N4FsPKyVjn05L8IAFy7h9r6oa', 'France', '', 'FR', '2016-10-05 03:54:58', 1, 'Thierry', '12465', 0),
(182, 'Arvind', 'balgo_arvind@hotmail.com', '456453', '$2a$10$0ed39eec54fd145e9eab9OhRpQqa8hRvsWAij3t/GVlBjPK1emEoq', '453453', '', 'FR', '2016-10-23 12:37:01', 0, 'Arvind', '12465', 0),
(183, '123456789', 'local@gmail.com', '123456789', '$2a$10$79e6137f87f208298355dOwTfG2TJ7BntYEu74sp4AcUY6dEu7sBa', '123456789', '', 'FR', '2016-10-25 20:26:30', 0, '123456789', '12465', 0),
(184, 'Kirty', 'kirty@gmail.com', '675942', '$2a$10$55af9227d2b388e5bfbc5uQ3pMuLlFUF.ekKC7qEe8amahs5pqP5W', 'GB', '', 'FR', '2016-11-22 02:06:38', 1, 'Kirty', '12465', 0),
(185, 'Vinita', 'vinita@gmail.com', '6175942', '$2a$10$85ca57b5e1a356467ec2fuLzwgev.d1kLCIOO0x18Mkt1zhk3vjTe', 'LBG', '', 'FR', '2016-11-28 10:16:58', 1, 'Vinita', '12465', 0),
(186, 'LauraDeg', 'tgungaram@gmail.com', '32129349394', '$2a$10$35fb69da97ec3ad5b3646urW78zOVLbhd9NK7oqUF9qFTuJNP0UCK', '22 Rue Du Jardin', '', 'FR', '2017-03-09 14:15:14', 0, 'LauraDeg', '12465', 0),
(187, 'Rajendra', 'rajendra.ballgobin@hotmail.com', '59125334', '$2a$10$e80dbf222f1288ddf527duE7AvmS5PnfSjPsxS6Fi5A7X9673n6T2', 'Le Grand BRanch road', 'Grand Bois', 'FR', '2017-07-04 03:36:18', 1, 'Ballgobin', '65507', 1),
(188, 'Operateur', 'operateurs@exakom.fr', '58888888', '$2a$10$9900574e246752ad80f66O3icLyLIx01AQutZ4n/vXqZM/k2pw6xK', 'Candos Lane', '', 'FR', '2017-07-04 03:51:06', 1, 'Operateur', '', 1);
