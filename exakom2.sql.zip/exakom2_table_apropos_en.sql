
-- --------------------------------------------------------

--
-- Table structure for table `apropos_en`
--

CREATE TABLE `apropos_en` (
  `id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apropos_en`
--

INSERT INTO `apropos_en` (`id`, `description`) VALUES
(1, 'Computing in general and Internet in particular revolutionise our professions while achieving significant\ncost reductions in our structure that EXAKOM wants you to benefit. You will therefore benefit a range of high quality products at extremely competitive prices, thus you pay a \'fair\' price. We market only familiar products to you, thus we don\'t specially need a sales force. We safeguard our environment by reducing the number of miles driven annually.\n\nWe have develop and automate our systems with maximum efficiency to assigned a large number of  tasks, however we are available to advise and assist you with your project.\nOur purpose is to guarantee your full satisfaction and preserving our environment.');
