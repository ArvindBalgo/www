
-- --------------------------------------------------------

--
-- Table structure for table `cata_support`
--

CREATE TABLE `cata_support` (
  `id` int(11) NOT NULL,
  `id_dimension` int(11) NOT NULL,
  `id_support` int(11) NOT NULL,
  `id_subcategory` int(11) NOT NULL,
  `prix_achat` float NOT NULL DEFAULT '0',
  `qte` int(11) NOT NULL DEFAULT '0',
  `coeff_support` float NOT NULL DEFAULT '0',
  `coeff_qte` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
