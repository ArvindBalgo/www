
-- --------------------------------------------------------

--
-- Table structure for table `tva`
--

CREATE TABLE `tva` (
  `id` int(11) NOT NULL,
  `value` float NOT NULL,
  `pays` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tva`
--

INSERT INTO `tva` (`id`, `value`, `pays`) VALUES
(1, 20, 'FR'),
(2, 0, 'EN'),
(3, 0, 'ES'),
(4, 0, 'AL'),
(5, 0, 'IT');
